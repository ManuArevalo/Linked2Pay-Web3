# Stub settlement handlers
def settle_via_ach(data): pass
def settle_via_fednow(data): pass
def settle_via_usdc(data): pass
def settle_via_eurc(data): pass
