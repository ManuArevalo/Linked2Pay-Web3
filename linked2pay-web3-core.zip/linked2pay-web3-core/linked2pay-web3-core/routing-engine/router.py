# Multi-rail routing logic (simplified)
def select_rail(params):
    rails = ['USDC', 'FedNow', 'ACH']
    if params.get('currency') == 'USDC':
        return 'USDC'
    elif params.get('speed') == 'instant':
        return 'FedNow'
    else:
        return 'ACH'
