# Linked2Pay Web3 Modular Payment Stack

This repo contains core modules for Linked2Pay's Web3 integration:

- Subscription Smart Contracts
- Multi-Rail Routing Engine
- Settlement Rail Handlers
- Compliance/KYC Layer
- Custody & Treasury Tools
